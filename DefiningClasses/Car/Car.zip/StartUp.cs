﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();

            car.Make = "Volkswagen";
            car.Model = "Golf";
            car.Year = 2017;

            Console.WriteLine($"Make: {car.Make}\n Model: {car.Model}\n Year: {car.Year}");
        }
    }
}
