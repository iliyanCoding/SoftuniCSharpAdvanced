﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarExtension
{
    internal class Class1
    {
    }
}
